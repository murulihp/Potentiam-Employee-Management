// Employee Management Application
class EmployeeManager {
    constructor() {
        this.employees = [];
        this.filteredEmployees = [];
        this.employeeModal = null;
        this.addEmployeeModal = null;
        this.init();
    }

    init() {
        // Wait for Bootstrap to be loaded
        if (typeof bootstrap !== 'undefined') {
            // Initialize Bootstrap modals
            this.employeeModal = new bootstrap.Modal(document.getElementById('employeeModal'));
            this.addEmployeeModal = new bootstrap.Modal(document.getElementById('addEmployeeModal'));
        } else {
            // Fallback for manual modal handling
            this.employeeModal = {
                show: () => document.getElementById('employeeModal').style.display = 'block',
                hide: () => document.getElementById('employeeModal').style.display = 'none'
            };
            this.addEmployeeModal = {
                show: () => document.getElementById('addEmployeeModal').style.display = 'block',
                hide: () => document.getElementById('addEmployeeModal').style.display = 'none'
            };
        }
        
        this.bindEventListeners();
        this.loadEmployees();
    }

    bindEventListeners() {
        // Search and filter
        document.getElementById('searchInput').addEventListener('input', (e) => {
            this.filterEmployees();
        });

        document.getElementById('departmentFilter').addEventListener('change', (e) => {
            this.filterEmployees();
        });

        // Modal controls
        document.getElementById('addEmployeeBtn').addEventListener('click', () => {
            this.showAddEmployeeModal();
        });

        // Add employee form
        document.getElementById('addEmployeeForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addEmployee();
        });
    }

    async loadEmployees() {
        try {
            this.showLoading();
            this.hideError();

            const response = await fetch('/api/employees');
            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || 'Failed to load employees');
            }

            if (result.success) {
                this.employees = result.data;
                this.filteredEmployees = [...this.employees];
                this.populateDepartmentFilter();
                this.renderEmployees();
                this.updateEmployeeCount();
            } else {
                throw new Error(result.error || 'Failed to load employees');
            }
        } catch (error) {
            console.error('Error loading employees:', error);
            this.showError(`Failed to load employees: ${error.message}`);
        } finally {
            this.hideLoading();
        }
    }

    async loadEmployeeDetails(employeeId) {
        try {
            const response = await fetch(`/api/employees/${employeeId}`);
            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || 'Failed to load employee details');
            }

            if (result.success) {
                this.showEmployeeDetails(result.data);
            } else {
                throw new Error(result.error || 'Failed to load employee details');
            }
        } catch (error) {
            console.error('Error loading employee details:', error);
            this.showError(`Failed to load employee details: ${error.message}`);
        }
    }

    async addEmployee() {
        try {
            const formData = new FormData(document.getElementById('addEmployeeForm'));
            const employeeData = {
                name: formData.get('name'),
                department: formData.get('department'),
                role: formData.get('role'),
                email: formData.get('email')
            };

            const response = await fetch('/api/employees', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(employeeData)
            });

            const result = await response.json();

            if (!response.ok) {
                throw new Error(result.error || 'Failed to add employee');
            }

            if (result.success) {
                this.hideAddEmployeeModal();
                document.getElementById('addEmployeeForm').reset();
                await this.loadEmployees(); // Reload the employee list
                this.showSuccess('Employee added successfully!');
            } else {
                throw new Error(result.error || 'Failed to add employee');
            }
        } catch (error) {
            console.error('Error adding employee:', error);
            this.showError(`Failed to add employee: ${error.message}`);
        }
    }

    filterEmployees() {
        const searchTerm = document.getElementById('searchInput').value.toLowerCase();
        const departmentFilter = document.getElementById('departmentFilter').value;

        this.filteredEmployees = this.employees.filter(employee => {
            const matchesSearch = employee.name.toLowerCase().includes(searchTerm) ||
                                employee.department.toLowerCase().includes(searchTerm) ||
                                employee.role.toLowerCase().includes(searchTerm) ||
                                employee.email.toLowerCase().includes(searchTerm);

            const matchesDepartment = !departmentFilter || employee.department === departmentFilter;

            return matchesSearch && matchesDepartment;
        });

        this.renderEmployees();
        this.updateEmployeeCount();
    }

    populateDepartmentFilter() {
        const departments = [...new Set(this.employees.map(emp => emp.department))].sort();
        const select = document.getElementById('departmentFilter');
        
        // Clear existing options (except "All Departments")
        select.innerHTML = '<option value="">All Departments</option>';
        
        departments.forEach(dept => {
            const option = document.createElement('option');
            option.value = dept;
            option.textContent = dept;
            select.appendChild(option);
        });
    }

    renderEmployees() {
        const grid = document.getElementById('employeeGrid');
        const emptyState = document.getElementById('emptyState');

        if (this.filteredEmployees.length === 0) {
            grid.innerHTML = '';
            emptyState.classList.remove('d-none');
        } else {
            emptyState.classList.add('d-none');
            grid.innerHTML = this.filteredEmployees.map(employee => this.createEmployeeCard(employee)).join('');
        }
    }

    createEmployeeCard(employee) {
        const departmentColors = {
            'Engineering': 'bg-primary text-white',
            'Human Resources': 'bg-success text-white',
            'Finance': 'bg-warning text-dark',
            'Sales & Marketing': 'bg-info text-white',
            'Technology': 'bg-secondary text-white',
            'Leadership': 'bg-danger text-white'
        };

        const departmentColor = departmentColors[employee.department] || 'bg-dark text-white';

        return `
            <div class="col-md-6 col-lg-4">
                <div class="card h-100 shadow-sm employee-card" data-employee-id="${employee.id}" style="cursor: pointer;">
                    <div class="card-body">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" 
                                 style="width: 50px; height: 50px; font-size: 1.2rem; font-weight: bold;">
                                ${employee.name.split(' ').map(n => n[0]).join('')}
                            </div>
                            <div>
                                <h5 class="card-title mb-1">${employee.name}</h5>
                                <small class="text-muted">ID: ${employee.id}</small>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="d-flex align-items-center mb-2">
                                <i class="fas fa-building text-muted me-2"></i>
                                <span class="small">${employee.department}</span>
                            </div>
                            <div class="d-flex align-items-center mb-2">
                                <i class="fas fa-user-tie text-muted me-2"></i>
                                <span class="small">${employee.role}</span>
                            </div>
                            <div class="d-flex align-items-center">
                                <i class="fas fa-envelope text-muted me-2"></i>
                                <span class="small">${employee.email}</span>
                            </div>
                        </div>
                        
                        <div class="mt-auto">
                            <span class="badge ${departmentColor}">${employee.department}</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    showEmployeeDetails(employee) {
        const modalContent = document.getElementById('modalContent');
        modalContent.innerHTML = `
            <div class="d-flex align-items-center mb-4">
                <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center me-3" 
                     style="width: 60px; height: 60px; font-size: 1.5rem; font-weight: bold;">
                    ${employee.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                    <h4 class="mb-1">${employee.name}</h4>
                    <p class="text-muted mb-0">Employee ID: ${employee.id}</p>
                </div>
            </div>
            
            <hr>
            
            <div class="row g-3 mt-2">
                <div class="col-12">
                    <label class="form-label fw-bold">Department</label>
                    <p class="mb-0">${employee.department}</p>
                </div>
                <div class="col-12">
                    <label class="form-label fw-bold">Role</label>
                    <p class="mb-0">${employee.role}</p>
                </div>
                <div class="col-12">
                    <label class="form-label fw-bold">Email</label>
                    <p class="mb-0">${employee.email}</p>
                </div>
            </div>
        `;
        
        this.employeeModal.show();
    }

    hideModal() {
        this.employeeModal.hide();
    }

    showAddEmployeeModal() {
        this.addEmployeeModal.show();
    }

    hideAddEmployeeModal() {
        this.addEmployeeModal.hide();
        document.getElementById('addEmployeeForm').reset();
    }

    updateEmployeeCount() {
        const countElement = document.getElementById('employeeCount');
        const total = this.employees.length;
        const filtered = this.filteredEmployees.length;
        
        if (total === filtered) {
            countElement.textContent = `Showing ${total} employee${total !== 1 ? 's' : ''}`;
        } else {
            countElement.textContent = `Showing ${filtered} of ${total} employee${total !== 1 ? 's' : ''}`;
        }
    }

    showLoading() {
        document.getElementById('loadingState').classList.remove('d-none');
        document.getElementById('employeeGrid').classList.add('d-none');
        document.getElementById('emptyState').classList.add('d-none');
    }

    hideLoading() {
        document.getElementById('loadingState').classList.add('d-none');
        document.getElementById('employeeGrid').classList.remove('d-none');
    }

    showError(message) {
        const errorState = document.getElementById('errorState');
        const errorMessage = document.getElementById('errorMessage');
        errorMessage.textContent = message;
        errorState.classList.remove('d-none');
    }

    hideError() {
        document.getElementById('errorState').classList.add('d-none');
    }

    showSuccess(message) {
        // Create a temporary success message using Bootstrap toast
        const toastContainer = document.getElementById('toastContainer') || this.createToastContainer();
        
        const toast = document.createElement('div');
        toast.className = 'toast show';
        toast.setAttribute('role', 'alert');
        toast.innerHTML = `
            <div class="toast-header bg-success text-white">
                <i class="fas fa-check-circle me-2"></i>
                <strong class="me-auto">Success</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        `;
        
        toastContainer.appendChild(toast);
        
        // Auto-hide after 3 seconds
        setTimeout(() => {
            toast.classList.add('fade');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    createToastContainer() {
        const container = document.createElement('div');
        container.id = 'toastContainer';
        container.className = 'toast-container position-fixed top-0 end-0 p-3';
        container.style.zIndex = '9999';
        document.body.appendChild(container);
        return container;
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Wait a bit for Bootstrap to be fully loaded
    setTimeout(() => {
        const employeeManager = new EmployeeManager();
        
        // Add click event listener for employee cards
        document.addEventListener('click', (e) => {
            const card = e.target.closest('.employee-card');
            if (card) {
                const employeeId = parseInt(card.dataset.employeeId);
                employeeManager.loadEmployeeDetails(employeeId);
            }
        });
    }, 100);
});
